const audio = document.getElementById("audio");
const playBtn = document.getElementById("playBtn");
const pauseBtn = document.getElementById("pauseBtn");
const muteBtn = document.getElementById("muteBtn");
const volumeSlider = document.getElementById("volume");
const progress = document.getElementById("progress");

// Play audio
playBtn.addEventListener("click", () => {
  audio.play();
});

// Pause audio
pauseBtn.addEventListener("click", () => {
  audio.pause();
});

// Mute/Unmute audio
muteBtn.addEventListener("click", () => {
  audio.muted = !audio.muted;
  muteBtn.textContent = audio.muted ? "Unmute" : "Mute";
});

// Volume control
volumeSlider.addEventListener("input", () => {
  audio.volume = volumeSlider.value;
});

// Progress bar update
audio.addEventListener("timeupdate", () => {
  progress.max = audio.duration;
  progress.value = audio.currentTime;
});

// Seek audio
progress.addEventListener("input", () => {
  audio.currentTime = progress.value;
});
